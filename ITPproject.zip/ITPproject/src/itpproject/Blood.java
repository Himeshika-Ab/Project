
package itpproject;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;

/**
 *
 * @author User S.Tiffany
 */

public class Blood extends Lab{
    
    int BRid;
    float glucosefast;
    float tsHormone;
    float cholesterol;
    float triglyceride;
    float hdl;
    float ldl;
    float vdl;
    float ratio;
    float bur;
    float pppglucose;
    
public Blood(String tn,String t,String ss, Boolean s,float c,String pn,double cn,int a,boolean sx,String pc,Date d,String ti)
    {
        super(tn,t,ss,s,c,pn,cn,a,sx,pc,d,ti);
    }
    
public Blood()
{
    
}

Connection con = DBconnect.getConnection();

//Constructor
public Blood(int id,float gf,float tsh,float ch,float tri,float hl,float ll,float vl,float ra,float bu,float pppg)
    {
     this.BRid=id;
     this.glucosefast = gf;
     this.tsHormone = tsh;
     this.cholesterol= ch;
     this.triglyceride = tri;
     this.hdl= hl;
     this.ldl=ll;
     this.vdl=vl;
     this.ratio=ra;
     this.bur=bu;
     this.pppglucose=pppg;
    
    
    }
    


//ADDING A BLOOD RESULT TO blood table 
public  void AddBloodResult(int tID,double glufast,double tsHormone,double cho,double tri,double hdl,double ldl,double vdl,double ratio,double bur,double pppglu)
{
    Connection con = null;
    PreparedStatement pst = null;
    con = DBconnect.getConnection();
    
    try{
          con = DBconnect.getConnection();
          String sql1 = "INSERT INTO bloodresults (testNo,glucoseF,tsHormone,cholesterol,triglyceride,hdl,ldl,vdl,ratio,bUrea,ppPlasmaGlu) value(?,?,?,?,?,?,?,?,?,?,?)";
          pst = con.prepareStatement(sql1);
             pst.setDouble(2, glufast);
             pst.setInt(1,tID);
             pst.setDouble(3, tsHormone);
             pst.setDouble(4, cho);
             pst.setDouble(5, tri);
             pst.setDouble(6, hdl);
             pst.setDouble(7, ldl);
             pst.setDouble(8, vdl);
             pst.setDouble(9, ratio);
             pst.setDouble(10,bur);
             pst.setDouble(11, pppglu);
        pst.executeUpdate();
        JOptionPane.showMessageDialog(null, "Blood Result Recorded", "ok", JOptionPane.INFORMATION_MESSAGE);  
        
        
}
    
    catch(Exception ex) {
        JOptionPane.showMessageDialog(null,ex.getMessage());
    }}

//UPDATE A BLOOD RESULT

public  void UpdateBloodR(int tID,double glufast,double tsHormone,double cho,double tri,double hdl,double ldl,double vdl,double ratio,double bur,double pppglu )
    {
       con = DBconnect.getConnection();
       try{
          String sql2 = "UPDATE test SET glucoseF = '"+ glufast +"', tsHormone = '"+tsHormone+"',cholesterol ='"+cho+"',triglyceride= '"+tri+"', hdl = '"+hdl+"',ldl='"+ldl+"',	vdl = '"+vdl+"', ratio='"+ratio+"', bUrea='"+bur+"',='"+pppglu+"' WHERE testNo ='"+tID+"' ";                             
          pst = con.prepareStatement(sql2);
          pst.execute();
          JOptionPane.showMessageDialog(null,"blood result record updated","ok",JOptionPane.INFORMATION_MESSAGE);
       
       }
       
       catch(Exception ex) {
       JOptionPane.showMessageDialog(null,ex.getMessage());
       }
    
    
    
    }

}
 