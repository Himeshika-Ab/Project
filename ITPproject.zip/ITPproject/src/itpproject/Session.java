/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package itpproject;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author Shalindri
 */
public class Session {
    private String sId;
    private String empNo;
    private String sTime;
    private String eTime;
    private int noOfApp;
    private double fee;
    private String status;
    private String  specialty;
    private String name;
   
    
   
    Session(String i,String e, String st,String et,int num,double f,String s,String sp,String n){
       
        this.sId=i;
        this.empNo=e;
        this.sTime =st;
        this.eTime = et;
        this.noOfApp = num;
        this.fee =f;
        this.status = s;
        this.specialty=sp;
        this.name=n;
        
        
      }
    Session(){}
    
    Session(String sp,String n){
    this.specialty=sp;
    this.name=n;
    
    }
  //fill speciality combo box 
   public static ResultSet fillCombo(){
        PreparedStatement pst= null;
        ResultSet rs = null;
        Connection con=null;
        try{
            con=DBconnect.getConnection();
            String query="select distinct Speciality  from doctor";
            pst=con.prepareStatement(query);
            rs=pst.executeQuery();

        } 
        catch (SQLException ex) {
            Logger.getLogger(Session.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
   }
   //fill Name combo box 
   public static ResultSet fillNameCombo(){
        PreparedStatement pst= null;
        ResultSet rs = null;
        Connection con=null;
        try{
            con=DBconnect.getConnection();
            String query="select distinct Speciality  from doctor";
            pst=con.prepareStatement(query);
            rs=pst.executeQuery();

        } 
        catch (SQLException ex) {
            Logger.getLogger(Session.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
   }
    
    public static ResultSet fillNameComboFiltered(String select,String combo){
      ResultSet rs=null;
        try{
            Connection con=DBconnect.getConnection();
            String query="select distinct name  from doctor where Speciality=?";
            PreparedStatement pst=con.prepareStatement(query); 
            pst.setString(1,select);
           
            rs=pst.executeQuery();
            while(rs.next()){
                String name=rs.getString("name");
                
            }
            
           
        }
        catch(SQLException ex){
               JOptionPane.showMessageDialog(null, ex.getMessage());
        }
        
        return rs;
   }
    
    
    //search function
    public ResultSet searchDoctor(String sp){
        PreparedStatement pst= null;
        ResultSet rs = null;
        Connection con=null;
        

         try 
        {
            
            con = DBconnect.getConnection();
            
           String sql = "Select * from doctor where Speciality =?"; //search query
           pst= (com.mysql.jdbc.PreparedStatement) con.prepareStatement(sql);  
         // pst.setString(1,sp);
           rs = pst.executeQuery(); 
            
        } 
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);
        }
         return rs;
       
    }
    //
    
    ////////////////////////////////////////////////////////////////////

   public int generateAppNo(int sessionID){
        int appNo=0;
        try{  
                    Connection con=DBconnect.getConnection();
                    con=DBconnect.getConnection();
	
                    String query = "select currentAppNo from session where sessionID = ?";
                    PreparedStatement pst =con.prepareStatement(query);
                    pst.setInt(1,sessionID);
                    ResultSet rs = pst.executeQuery();
                    while(rs.next()){
                    int aApp=rs.getInt("currentAppNo");
                    appNo=aApp+1;
                    }
                    
        }
        catch(Exception e){
                  JOptionPane.showMessageDialog(null, e.getMessage());  
                }
        return appNo;
    }
   
       public String calAprxTime(int sessionID){
   String ApTime=null;
        try{  
                    Connection con=DBconnect.getConnection();
                    con=DBconnect.getConnection();
	
                    String query = "select startTime,endTime ,noOfApp ,avilableApp from session where sessionID = ?";
                    PreparedStatement pst =con.prepareStatement(query);
                    pst.setInt(1,sessionID);
                    ResultSet rs = pst.executeQuery();
                   while(rs.next()){
                    String sTime=rs.getString("startTime");
                    String eTime=rs.getString("endTime");
                    int totalApp=rs.getInt("noOfApp");
                    int availableApp=rs.getInt("avilableApp");
                  
                  
                  
                    
                    //java.util.Date sTime1 = new Date(rs.getDate("startTime").getTime());
                   // java.util.Date eTime1 = new Date(rs.getDate("endTime").getTime());
        
                  //  String time1 = sTime;
                  //  String time2 = eTime;
                    
                    SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
                   
                        java.util.Date sTime1 = format.parse(sTime);
                        java.util.Date eTime1 = format.parse(eTime);
                        long diff = eTime1.getTime() - sTime1.getTime();
                        java.sql.Date sTime3=new java.sql.Date(sTime1.getTime());
                        
                   int duration=(int) TimeUnit.MINUTES.convert(diff, TimeUnit.MILLISECONDS);
              //     int sTime2=(int) TimeUnit.MINUTES.convert(sTime1.getTime(), TimeUnit.MILLISECONDS);
                  // int eTime2=(int) TimeUnit.SECONDS.convert(eTime1.getTime(), TimeUnit.MILLISECONDS);
                   
                    
                    int aprxTime = (duration*(availableApp)/totalApp);
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(sTime3);
                    cal.add(Calendar.MINUTE, aprxTime);
                    ApTime = format.format(cal.getTime());
                    
                   
                
        }}
        catch(Exception e){
                  JOptionPane.showMessageDialog(null, e.getMessage());  
                }
		
        
return ApTime;
       }
    
    
     public void EnterAppointment(String time,int appNo,int sessionID,int patientID,double fee,String source){ //enter Appointment details into Appointment table
	
                try{  
                    Connection con=DBconnect.getConnection();
                    con=DBconnect.getConnection();
	
		
                String query2 = "insert into appointment(date,time,appNo,sessionID,patientID,fee,source) values(?,?,?,?,?,?,?)";
                String query3 = "select date from session where sessionID = ?";
               // String query4 = "update session set currentAppNo = ? where sessionID=?";
                
                
                PreparedStatement pst2 =con.prepareStatement(query2);
                PreparedStatement pst3 =con.prepareStatement(query3);
              //  PreparedStatement pst4 =con.prepareStatement(query4);
                
         
         //get date from session Table  
         
                pst3.setInt(1,sessionID);
                ResultSet rs = pst3.executeQuery();
                
        //insert into Appointment table    
                if(rs.next()){
                pst2.setDate(1,rs.getDate("date")); 
                pst2.setString(2,time);
                pst2.setInt(3,appNo);
                pst2.setInt(4,sessionID);
                pst2.setInt(5,patientID);       
                pst2.setDouble(6,fee);
                 pst2.setString(7,source);
                
               
              int status= pst2.executeUpdate();
              if(status>0){
                  JOptionPane.showMessageDialog(null,"Appointment has been placed successfully");  
                  
              }
               
                }
                /*
        //update Session table
                if(rs.next()){
                   // currentApp=rs.getInt("currentAppNo");
                    pst4.setInt(1,appNo );
                    pst4.setInt(2,sessionID);
                    pst4.executeUpdate();  
                }
*/
                }
                catch(Exception e){
                  JOptionPane.showMessageDialog(null, e.getMessage());  
                }
		
        }
      public int UpdateCurrentApp(int sessionID,int appNo){ //update currentAppointmet no in session  table when placing an appointment 
	int status=0;
	
	try{
		Connection con=DBconnect.getConnection();
		
		
                        String query2="update session set currentAppNo= ? where sessionID=?";
                        PreparedStatement pst2=con.prepareStatement(query2);
                        pst2.setInt(1,appNo);
                   
                        pst2.setInt(2,sessionID);
		
                        status=pst2.executeUpdate();
		
		con.close();}
                catch(Exception e){System.out.println(e);}
	return status;
}
     
     
     public int UpdateAvailableApp(int sessionID){ //update session  table when placing an appointment (available+1)
	int status=0;
	int available=0;
	try{
		Connection con=DBconnect.getConnection();
		String query ="select avilableApp from session where sessionID=?";
		PreparedStatement ps=con.prepareStatement(query);
		ps.setInt(1,sessionID);
		ResultSet rs=ps.executeQuery();
		if(rs.next()){ 
			//total=rs.getInt("noOfApp");
			available=rs.getInt("avilableApp");
		
                        String query2="update session set avilableApp= ? where sessionID=?";
                        PreparedStatement pst2=con.prepareStatement(query2);
                        pst2.setInt(1,available+1);
                   
                        pst2.setInt(2,sessionID);
		
		status=pst2.executeUpdate();
		}
		con.close();
	}catch(Exception e){System.out.println(e);}
	return status;
}
        public void UpdateFillAction(int sessionID){ //update action As Filled in session table

	try{
		Connection con=DBconnect.getConnection();
		
                        String query2="update session set action= 'Filled' where sessionID=?";
                        PreparedStatement pst2=con.prepareStatement(query2);
                        pst2.setInt(1,sessionID);
                        pst2.executeUpdate();
		
		con.close();}
                catch(Exception e){System.out.println(e);}
	
}
        
        public int UpdateStatusBlocked(int sessionID){ //update status As blocked in session table
            int status=0;   
	try{
		Connection con=DBconnect.getConnection();
		
                        String query2="update session set status= 'Blocked' where sessionID=?";
                        PreparedStatement pst2=con.prepareStatement(query2);
                        pst2.setInt(1,sessionID);
                        status=pst2.executeUpdate();
		
		con.close();}
                catch(Exception e){System.out.println(e);}
            return status;	
}
        public int UpdateStatusAvailable(int sessionID){ //update status As Available in session table
            int status=0;   
	try{
		Connection con=DBconnect.getConnection();
		
                        String query2="update session set status= 'Available' where sessionID=?";
                        PreparedStatement pst2=con.prepareStatement(query2);
                        pst2.setInt(1,sessionID);
                        status=pst2.executeUpdate();
		
		con.close();}
                catch(Exception e){System.out.println(e);}
            return status;	
}
     
     //Cancel An Appointment---------------------------------------------------------------------------------------------------------------------------
     
     
     
     public void deleteAppointment(int apRefNo)//delete appointment details from Appointment table
{
                
    try{
                Connection con=DBconnect.getConnection();
                String query = "DELETE FROM appointment WHERE apRefNo =?";
                PreparedStatement pst =con.prepareStatement(query);
                pst.setInt(1, apRefNo);
             
                pst.executeUpdate();
                JOptionPane.showMessageDialog(null, "The Appointment has canceled successfully.");
        }
          catch(Exception e){
                JOptionPane.showMessageDialog(null,e);
       } 
}
     
         public int deleteAvailableApp(int sessionID){ //update session  table when deleting an appointment (available-1)
	int status=0;
	int available=0;
	try{
		Connection con=DBconnect.getConnection();
		String query ="select avilableApp from session where sessionID=?";
		PreparedStatement ps=con.prepareStatement(query);
		ps.setInt(1,sessionID);
		ResultSet rs=ps.executeQuery();
		if(rs.next()){ 
			//total=rs.getInt("noOfApp");
			available=rs.getInt("avilableApp");
		
                        String query2="update session set avilableApp= ? where sessionID=?";
                        PreparedStatement pst2=con.prepareStatement(query2);
                        pst2.setInt(1,available-1);
                       // pst2.setInt(2,issued-1);
                        pst2.setInt(2,sessionID);
		
		status=pst2.executeUpdate();
		}
		con.close();
	}catch(Exception e){System.out.println(e);}
	return status;
}    
	
		
	public void refund(int apRfNo){
             try{  
                    Connection con=DBconnect.getConnection();
                    con=DBconnect.getConnection();
	
		
                String query1 = "insert into refund(apRefNo,patientID,total) values(?,?,?)";
                String query2 = "select a.patientID,a.fee from appointment a,session s where a.sessionId=s.sessionID and apRefNo = ?";
                
                
                PreparedStatement pst2 =con.prepareStatement(query1);
                PreparedStatement pst3 =con.prepareStatement(query2);
                
         
         //get patientID from Appointment Table  
         
                pst3.setInt(1,apRfNo);
                ResultSet rs = pst3.executeQuery();
                
        //insert into Refund table  
                pst2.setInt(1,apRfNo);
                if(rs.next()){
                pst2.setInt(2,rs.getInt("patientID"));
                pst2.setDouble(3,rs.getDouble("fee"));}
            
               pst2.executeUpdate();
              
                }
                catch(Exception e){
                  JOptionPane.showMessageDialog(null, e.getMessage());  
                }
		
            
        }
        
        public void UpdateUnFillAction(int sessionID){ //update action As Filled in session table

	try{
		Connection con=DBconnect.getConnection();
		
                        String query2="update session set action= 'UnFilled' where sessionID=?";
                        PreparedStatement pst2=con.prepareStatement(query2);
                        pst2.setInt(1,sessionID);
                        pst2.executeUpdate();
		
		con.close();}
                catch(Exception e){System.out.println(e);}
	
}
        

        
}
    

