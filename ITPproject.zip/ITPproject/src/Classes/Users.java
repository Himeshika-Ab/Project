/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import itpproject.DBconnect;

/**
 *
 * @author Admin
 */
public class Users {
    private String user;
    private String pass;
    private String role;
    Connection conn = null;
    
    public Users(){
        conn = DBconnect.getConnection();
    }
    
    public void addUser(String u, String p, String r){
        String q1 = "INSERT INTO users VALUES (?, ?, ?)";
        try{
             PreparedStatement pst = conn.prepareStatement(q1);
             user = u;
             pass = p;
             role = r;
             pst.setString(1, user);
             pst.setString(2, pass);
             pst.setString(3, role);
             pst.executeUpdate();
              JOptionPane.showMessageDialog(null, "1 User succesfully added!");
        }
        catch(Exception e){
             JOptionPane.showMessageDialog(null, e.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public ResultSet validateUser(String u, String p){
        ResultSet rs = null;
    String q1 = "SELECT role FROM users WHERE username = ? AND password = ?";
        try{
             PreparedStatement pst = conn.prepareStatement(q1);
             user = u;
             pass = p;
             
             pst.setString(1, user);
             pst.setString(2, pass);
             
             rs = pst.executeQuery();
             
        }
        catch(Exception e){
             JOptionPane.showMessageDialog(null, e.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
        }
        return rs;
    }
    
}
